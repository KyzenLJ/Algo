package co.simplon.algo;

public class MathRandom {

	public static void main(String[] args) {
		
		if (resultat<25) {	
		System.out.println("Votre résultat est inférieur à 25");
		}
		else if (resultat>25) {
			System.out.println("Votre résultat est supérieur à 25");
		}
		else {
			System.out.println("Votre résultat est 25");
		}
		public static int resultat (getRandaomArbitrary) {
			int min = 0;
			int max = 50;
			int getRandomArbitrary = (int)(Math.random() * (max - min)) + min; 
		
	}
	}

}
