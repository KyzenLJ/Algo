package co.simplon.algo;

public class Coucou {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String alex = "Alex";
				System.out.println("Coucou " + alex);
	}

}
